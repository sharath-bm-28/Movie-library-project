

//restorents information are stored in this file using Fixtures
var FIXTURES = window.FIXTURES || {};

FIXTURES.movies ={

    movie1:{
        name:"Pirates of Caribbean",
        rating:"4.5",
        genres:"comedy",
        comment:"very Good"
    },
    movie2:{
        name:"Jungle Cruise",
        rating:"4.8",
        genres:"adventure",
        comment:"excelent movie"
    },
    movie3:{
        name:"Fast and Furious",
        rating:"4.3",
        genres:"action",
        comment:"Good"
    },
    movie4:{
        name:"Death of Me",
        rating:"4.5",
        genres:"horror",
        comment:"Good"
    },
}